package mx.edu.ittepic.dam_u4_proyecto1_19400608

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
