import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'vehiculo.dart';

class CrearVehiculo extends StatefulWidget {
  @override
  _CrearVehiculoState createState() => _CrearVehiculoState();
}

class _CrearVehiculoState extends State<CrearVehiculo> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _placaController = TextEditingController();
  final TextEditingController _numeroSerieController = TextEditingController();
  final TextEditingController _tanqueController = TextEditingController();
  final TextEditingController _trabajadorController = TextEditingController();
  final TextEditingController _resguardadoPorController = TextEditingController();
  String _tipoValue = "Camion";
  String _gasolinaValue = "Diesel";
  String _departamentoValue = "Materiales";

  Future<void> _agregarVehiculo() async {
    try {
      Vehiculo vehiculo = Vehiculo(
        placa: _placaController.text,
        tipo: _tipoValue,
        numeroSerie: _numeroSerieController.text,
        combustible: _gasolinaValue,
        tanque: int.parse(_tanqueController.text),
        trabajador: _trabajadorController.text,
        departamento: _departamentoValue,
        resguardadoPor: _resguardadoPorController.text,
      );

      await FirebaseFirestore.instance
          .collection('vehiculo')
          .add(vehiculo.toMap());
      Navigator.pop(context);
    } catch (e) {
      print('Error al agregar el vehículo: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            title: Text('Crear vehículo'),
        ),
        body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
            TextFormField(
              controller: _placaController,
              decoration: InputDecoration(
                labelText: 'Placa',
              ),
              validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Por favor, ingrese la placa';
              }
              return null;
              },
            ),
              DropdownButtonFormField<String>(
                value: _tipoValue,
                onChanged: (String? value1) {
                  setState(() {
                    _tipoValue = value1 ?? _tipoValue;
                  });
                },
                items: <String>[
                  'Camion',
                  'Coche',
                  'Camioneta',
                  'Tractor',
                  'Motocicleta',
                ].map<DropdownMenuItem<String>>((String value1) {
                  return DropdownMenuItem<String>(
                    value: value1,
                    child: Text(value1),
                  );
                }).toList(),
                decoration: InputDecoration(
                  labelText: 'Tipo',
                ),
                validator: (value1) {
                  if (value1 == null || value1.isEmpty) {
                    return 'Por favor, seleccione el tipo de vehículo';
                  }
                  return null;
                },
              ),

              TextFormField(
              controller: _numeroSerieController,
              decoration: InputDecoration(
                labelText: 'Número de serie',
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Por favor, ingrese el número de serie';
                }
                return null;
              },
            ),
              DropdownButtonFormField<String>(
                value: _gasolinaValue,
                onChanged: (String? value2) {
                  setState(() {
                    _gasolinaValue = value2 ?? _gasolinaValue;
                  });
                },
                items: <String>[
                  'Diesel',
                  'Regular',
                  'Premium',
                ].map<DropdownMenuItem<String>>((String value2) {
                  return DropdownMenuItem<String>(
                    value: value2,
                    child: Text(value2),
                  );
                }).toList(),
                decoration: InputDecoration(
                  labelText: 'Gasolina',
                ),
                validator: (value2) {
                  if (value2 == null || value2.isEmpty) {
                    return 'Por favor, seleccione el tipo de gasolina';
                  }
                  return null;
                },
              ),

              TextFormField(
              controller: _tanqueController,
              decoration: InputDecoration(
                labelText: 'Capacidad del tanque (en litros)',
              ),
              keyboardType: TextInputType.number,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Por favor, ingrese la capacidad del tanque';
                } else if (int.tryParse(value) == null) {
                  return 'Por favor, ingrese un número válido';
                }
                return null;
              },
            ),
              TextFormField(
                controller: _trabajadorController,
                decoration: InputDecoration(
                  labelText: 'Trabajador responsable',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, ingrese el nombre del trabajador responsable';
                  }
                  return null;
                },
              ),
              DropdownButtonFormField<String>(
                value: _departamentoValue,
                onChanged: (String? value3) {
                  setState(() {
                    _departamentoValue = value3 ?? _departamentoValue;
                  });
                },
                items: <String>[
                  'Materiales',
                  'Jardineria',
                  'Direccion',
                  'Seguridad',
                  'Otro',
                ].map<DropdownMenuItem<String>>((String value3) {
                  return DropdownMenuItem<String>(
                    value: value3,
                    child: Text(value3),
                  );
                }).toList(),
                decoration: InputDecoration(
                  labelText: 'Departamento',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, seleccione el departamento';
                  }
                  return null;
                },
              ),

              TextFormField(
                controller: _resguardadoPorController,
                decoration: InputDecoration(
                  labelText: 'Resguardado por',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, ingrese el nombre de la persona que resguardará el vehículo';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20.0),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _agregarVehiculo();
                  }
                },
                child: Text('Agregar'),
              ),
            ],
          ),
        ),
        ),
    );
  }
}