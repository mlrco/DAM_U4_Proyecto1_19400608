import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'vehiculo.dart';
import 'crearVehiculo.dart';
import 'detalleVehiculo.dart';
import 'firebase_options.dart';
import 'bd.dart';

class ListaVehiculos extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return _ListaVehiculos();
  }
}

class _ListaVehiculos extends State<ListaVehiculos> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Lista de vehículos'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('vehiculo').snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
          List<Vehiculo> vehiculos = snapshot.data!.docs.map((doc) => Vehiculo.fromMap(doc.data() as Map<String, dynamic>?)).toList();
          return ListView.builder(
            itemCount: vehiculos.length,
            itemBuilder: (context, index) {
              return ListTile(
                title: Text(vehiculos[index].placa ?? 'Sin placa'),
                subtitle: Text(vehiculos[index].tipo ?? 'Sin tipo'),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => DetalleVehiculo(vehiculo: vehiculos[index])),
                  );
                },
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          agregarVehiculo(context);
        },
        tooltip: 'Agregar Vehículo',
        child: Icon(Icons.add),
      ),
    );
  }
  void agregarVehiculo(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => CrearVehiculo()),
    );
  }
}
