class Bitacora {
  String? id;
  String? placa;
  String? fecha;
  String? evento;
  String? recursos;
  String? verifico;
  String? fechaVerificacion;

  Bitacora({
    this.id,
    this.placa,
    this.fecha,
    this.evento,
    this.recursos,
    this.verifico,
    this.fechaVerificacion,
  });

  Map<String, dynamic> toMap() {
    return {
      'placa': placa,
      'fecha': fecha,
      'evento': evento,
      'recursos': recursos,
      'verifico': verifico,
      'fechaVerificacion': fechaVerificacion,
    };
  }

  factory Bitacora.fromMap(String id, Map<String, dynamic> map) {
    return Bitacora(
      id: id,
      placa: map['placa'] as String,
      fecha: map['fecha'] as String,
      evento: map['evento'] as String,
      recursos: map['recursos'] as String,
      verifico: map['verifico'] as String,
      fechaVerificacion: map['fechaVerificacion'] as String,
    );
  }
}
