import 'package:cloud_firestore/cloud_firestore.dart';
import 'vehiculo.dart';
import 'firebase_options.dart';

FirebaseFirestore db = FirebaseFirestore.instance;

class VehiculoFirestoreService {
  final CollectionReference _vehiculosCollection =
  FirebaseFirestore.instance.collection('vehiculo');

  // Método para obtener todos los vehículos
  Future<List<Vehiculo>> getVehiculos() async {
    QuerySnapshot snapshot = await _vehiculosCollection.get();
    List<Vehiculo> vehiculos =
    snapshot.docs.map((doc) => Vehiculo.fromMap(doc.data() as Map<String, dynamic>?)).toList();
    return vehiculos;
  }

  // Método para obtener un vehículo por su ID
  Future<Vehiculo> getVehiculoById(String id) async {
    DocumentSnapshot snapshot = await _vehiculosCollection.doc(id).get();
    return Vehiculo.fromMap(snapshot.data() as Map<String, dynamic>?);
  }

  // Método para crear un vehículo
  Future<void> createVehiculo(Vehiculo vehiculo) async {
    await _vehiculosCollection.add(vehiculo.toMap());
  }

  // Método para actualizar un vehículo
  Future<void> updateVehiculo(Vehiculo vehiculo) async {
    await _vehiculosCollection.doc(vehiculo.placa).update(vehiculo.toMap());
  }

  // Método para eliminar un vehículo
  Future<void> deleteVehiculo(String id) async {
    await _vehiculosCollection.doc(id).delete();
  }
}
