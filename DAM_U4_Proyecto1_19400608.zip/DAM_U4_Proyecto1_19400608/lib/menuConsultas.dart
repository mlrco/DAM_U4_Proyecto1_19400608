import 'package:dam_u4_proyecto1_19400608/consultaPorDepto.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'consultaPorPlaca.dart';
import 'consultaPorFecha.dart';

class BitacoraScreen extends StatefulWidget {
  @override
  _BitacoraScreenState createState() => _BitacoraScreenState();
}

class _BitacoraScreenState extends State<BitacoraScreen> {
  final TextEditingController _placaController = TextEditingController();
  String? _deptoSeleccionado = 'Materiales';
  DateTime _fechaSeleccionada = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Consultas'),
      ),
      body: Column(
        children: [
          SizedBox(height: 16),
          Row(children: [

            SizedBox( width: 125, child:
            DropdownButtonFormField<String>(
            value: _deptoSeleccionado,
            onChanged: (value) {
              setState(() {
                _deptoSeleccionado = value;
              });
            },
            items: <String>[
              'Materiales',
              'Jardineria',
              'Direccion',
              'Seguridad',
              'Otro',
            ].map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
            decoration: InputDecoration(
              labelText: 'Departamento',
              border: OutlineInputBorder(),
            ),
          ),
            ),
            SizedBox(width: 85,),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ConsultaPorDepartamentoScreen(
                      deptoSeleccionado: _deptoSeleccionado ?? "",
                    ),
                  ),
                );
              },
              child: Text('Consultar por depto'),
            ),
          ],
          ),
          SizedBox(height: 50),




          Row(
            children: [
              SizedBox(width: 125, child:
              TextField(
                controller: _placaController,
                decoration: InputDecoration(
                  labelText: 'Placa',
                  border: OutlineInputBorder(),
                ),
              ),
              ),
              SizedBox(width: 85,),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ConsultaPorPlacaScreen(
                        placa: _placaController.text,
                      ),
                    ),
                  );
                },
                child: Text('Consultar por placa'),
              ),
      ],
    ),

              SizedBox(height: 50),
              Row(children:[
                ElevatedButton(
                  onPressed: () async {
                    final DateTime? date = await showDatePicker(
                      context: context,
                      initialDate: _fechaSeleccionada,
                      firstDate: DateTime(2021),
                      lastDate: DateTime(2025),
                    );
                    if (date != null) {
                      setState(() {
                        _fechaSeleccionada = date;
                      });
                    }
                  },
                  child: Text('Seleccionar fecha'),
                ),
              SizedBox(width: 125,),
              ElevatedButton(
                onPressed: () {
                  final formattedDate =
                  DateFormat('dd/MM/yyyy').format(_fechaSeleccionada);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ConsultaPorFechaScreen(
                        fechaConsulta: formattedDate,
                      ),
                    ),
                  );
                },
                child: Text('Consultar por fecha'),
              ),

            ],
              ),
      ],
      ),
    );
  }
}
