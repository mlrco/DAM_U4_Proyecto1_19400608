import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'bitacora.dart';
import 'package:intl/intl.dart';
import 'vehiculo.dart';

class AgregarRegistroBitacora extends StatefulWidget {
  final String placa;

  AgregarRegistroBitacora({required this.placa});

  @override
  _AgregarRegistroBitacoraState createState() =>
      _AgregarRegistroBitacoraState();
}

class _AgregarRegistroBitacoraState extends State<AgregarRegistroBitacora> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _fechaSalidaController;
  late TextEditingController _eventoController;
  late TextEditingController _recursosController;
  late TextEditingController _verificoController;
  late TextEditingController _fechaVerificacionController;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _fechaSalidaController = TextEditingController();
    _eventoController = TextEditingController();
    _recursosController = TextEditingController();
    _verificoController = TextEditingController();
    _fechaVerificacionController = TextEditingController();
  }

  @override
  void dispose() {
    _fechaSalidaController.dispose();
    _eventoController.dispose();
    _recursosController.dispose();
    _verificoController.dispose();
    _fechaVerificacionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Agregar Registro de Bitácora'),
      ),
      body: Container(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: <Widget>[
              TextFormField(
                controller: _fechaSalidaController,
                decoration: InputDecoration(
                  labelText: 'Fecha de salida',
                ),
                readOnly: true,
                onTap: () {
                  _selectDate(context, _fechaSalidaController);
                },
              ),
              SizedBox(height: 10.0),
              TextFormField(
                controller: _eventoController,
                decoration: InputDecoration(
                  labelText: 'Evento',
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Por favor ingrese el evento';
                  }
                  return null;
                },
              ),
              SizedBox(height: 10.0),
              TextFormField(
                controller: _recursosController,
                decoration: InputDecoration(
                  labelText: 'Recursos',
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Por favor ingrese los recursos';
                  }
                  return null;
                },
              ),
              SizedBox(height: 10.0),
              TextFormField(
                controller: _verificoController,
                decoration: InputDecoration(
                  labelText: 'Verificó',
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Por favor ingrese quien verificó';
                  }
                  return null;
                },
              ),
              SizedBox(height: 10.0),

              TextFormField(
                decoration: InputDecoration(labelText: 'Fecha de verificación'),
                controller: _fechaVerificacionController,
                readOnly: true,
                onTap: () {
                  _selectDate(context, _fechaVerificacionController);
                },
              ),

              SizedBox(height: 20.0),

              // Botón de guardar
              ElevatedButton(
                onPressed: () {
                  _guardarRegistro();
                },
                child: Text('Guardar'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Función para seleccionar una fecha con el DatePicker
  Future<void> _selectDate(
      BuildContext context, TextEditingController controller) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(1900),
        lastDate: DateTime(2100));
    if (picked != null) {
      setState(() {
        controller.text = DateFormat('dd/MM/yyyy').format(picked);
      });
    }
  }

  // Función para guardar el registro en Firestore
  void _guardarRegistro() async {
    try {
      // Crear un nuevo objeto Bitacora a partir de los datos ingresados en los campos
      Bitacora nuevoRegistro = Bitacora(
        placa: widget.placa,
        fecha: _fechaSalidaController.text,
        evento: _eventoController.text,
        recursos: _recursosController.text,
        verifico: _verificoController.text,
        fechaVerificacion: _fechaVerificacionController.text,
      );

      // Agregar el registro a Firestore
      await FirebaseFirestore.instance
          .collection('bitacoras')
          .add(nuevoRegistro.toMap());

      // Mostrar mensaje de éxito y volver a la pantalla de detalle de vehículo
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Registro agregado exitosamente'),
          duration: Duration(seconds: 2),
        ),
      );
      Navigator.of(context).pop();
    } catch (error) {
      // Mostrar mensaje de error si falla la creación del registro
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error al agregar el registro'),
          duration: Duration(seconds: 2),
        ),
      );
      print('Error al agregar el registro: $error');
    }
  }
}

