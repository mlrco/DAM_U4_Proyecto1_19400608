import 'package:dam_u4_proyecto1_19400608/detalleVehiculo.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'vehiculo.dart';

class ConsultaPorDepartamentoScreen extends StatelessWidget {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final String deptoSeleccionado;

  ConsultaPorDepartamentoScreen({required this.deptoSeleccionado});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Consulta por departamento'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            'Vehículos del departamento $deptoSeleccionado',
            style: TextStyle(
              fontSize: 24.0,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 20.0),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: _db
                  .collection('vehiculo')
                  .where('departamento', isEqualTo: deptoSeleccionado)
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                }
                List<Vehiculo> vehiculos = [];
                snapshot.data!.docs.forEach((doc) {
                  vehiculos.add(Vehiculo.fromMap(doc.data() as Map<String, dynamic>?));
                });

                return ListView.builder(
                  itemCount: vehiculos.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      title: Text(vehiculos[index].placa ?? ""),
                      subtitle: Text("${vehiculos[index].tipo} - N.S. ${vehiculos[index].numeroSerie}"),
                      onTap: () {

                      },
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
