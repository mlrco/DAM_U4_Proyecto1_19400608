import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ConsultaPorFechaScreen extends StatefulWidget {
  final String fechaConsulta;

  ConsultaPorFechaScreen({required this.fechaConsulta});

  @override
  _ConsultaPorFechaScreenState createState() => _ConsultaPorFechaScreenState();
}

class _ConsultaPorFechaScreenState extends State<ConsultaPorFechaScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Consulta por Fecha'),
      ),
      body: Container(
        padding: EdgeInsets.all(16.0),
        child: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance
              .collection('bitacoras')
              .where('fecha', isEqualTo: widget.fechaConsulta)
              .snapshots(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) {
              return Center(child: CircularProgressIndicator());
            }

            return ListView.builder(
              itemCount: snapshot.data!.docs.length,
              itemBuilder: (context, index) {
                var bitacora = snapshot.data!.docs[index];
                return ListTile(
                  title: Text(bitacora['placa']),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Fecha: ${bitacora['fecha']}'),
                      Text('Evento: ${bitacora['evento']}'),
                      Text('Recursos: ${bitacora['recursos']}'),
                      Text('Verificó: ${bitacora['verifico']}'),
                      Text('Fecha de Verificación: ${bitacora['fechaVerificacion']}'),
                    ],
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
