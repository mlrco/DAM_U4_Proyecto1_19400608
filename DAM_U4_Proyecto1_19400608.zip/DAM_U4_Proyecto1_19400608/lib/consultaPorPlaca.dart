import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'detalleBitacora.dart';

class ConsultaPorPlacaScreen extends StatefulWidget {
  final String placa;
  ConsultaPorPlacaScreen({required this.placa});

  @override
  _ConsultaPorPlacaScreenState createState() => _ConsultaPorPlacaScreenState();
}

class _ConsultaPorPlacaScreenState extends State<ConsultaPorPlacaScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Consulta por Placa'),
      ),
      body: Container(
        padding: EdgeInsets.all(16.0),
        child: StreamBuilder(
          stream: FirebaseFirestore.instance
              .collection('bitacoras')
              .where('placa', isEqualTo: widget.placa)
              .snapshots(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) {
              return Center(
                child: CircularProgressIndicator(),
              );
            } else {
              return ListView.builder(
                itemCount: snapshot.data!.docs.length,
                itemBuilder: (context, index) {
                  DocumentSnapshot ds = snapshot.data!.docs[index];
                  return Card(
                    child: ListTile(
                      title: Text(ds['evento']),
                      subtitle: Text(ds['fecha']),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => DetalleBitacoraScreen(id: ds.id),
                          ),
                        );
                      },
                    ),
                  );
                },
              );
            }
          },
        ),
      ),
    );
  }
}
