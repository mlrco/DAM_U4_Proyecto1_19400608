import 'package:flutter/material.dart';
import 'vehiculo.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'registroBitacora.dart';

class DetalleVehiculo extends StatefulWidget {
  final Vehiculo vehiculo;

  DetalleVehiculo({required this.vehiculo});

  @override
  _DetalleVehiculoState createState() => _DetalleVehiculoState();
}

class _DetalleVehiculoState extends State<DetalleVehiculo> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _numeroSerieController;
  late TextEditingController _tanqueController;
  late TextEditingController _trabajadorController;
  late TextEditingController _resguardadoPorController;
  String? _tipoValue = '';
  String? _gasolinaValue = '';
  String? _departamentoValue = '';

  @override
  void initState() {
    super.initState();
    _numeroSerieController = TextEditingController(text: widget.vehiculo.numeroSerie);
    _tanqueController = TextEditingController(text: widget.vehiculo.tanque.toString());
    _trabajadorController = TextEditingController(text: widget.vehiculo.trabajador);
    _resguardadoPorController = TextEditingController(text: widget.vehiculo.resguardadoPor);
    _tipoValue = widget.vehiculo.tipo;
    _gasolinaValue = widget.vehiculo.combustible;
    _departamentoValue = widget.vehiculo.departamento;
  }

  @override
  void dispose() {
    _numeroSerieController.dispose();
    _tanqueController.dispose();
    _trabajadorController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detalle de vehículo: ${widget.vehiculo.placa}'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              DropdownButtonFormField<String>(
                value: _tipoValue,
                onChanged: (String? value1) {
                  setState(() {
                    _tipoValue = value1 ?? _tipoValue;
                  });
                },
                items: <String>[
                  'Camion',
                  'Coche',
                  'Camioneta',
                  'Tractor',
                  'Motocicleta',
                ].map<DropdownMenuItem<String>>((String value1) {
                  return DropdownMenuItem<String>(
                    value: value1,
                    child: Text(value1),
                  );
                }).toList(),
                decoration: InputDecoration(
                  labelText: 'Tipo',
                ),
                validator: (value1) {
                  if (value1 == null || value1.isEmpty) {
                    return 'Por favor, seleccione el tipo de vehículo';
                  }
                  return null;
                },
              ),

              TextFormField(
                controller: _numeroSerieController,
                decoration: InputDecoration(
                  labelText: 'Número de serie',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, ingrese el número de serie';
                  }
                  return null;
                },
              ),
              DropdownButtonFormField<String>(
                value: _gasolinaValue,
                onChanged: (String? value2) {
                  setState(() {
                    _gasolinaValue = value2 ?? _gasolinaValue;
                  });
                },
                items: <String>[                  'Diesel',                  'Regular',                  'Premium',                ].map<DropdownMenuItem<String>>((String value2) {
                  return DropdownMenuItem<String>(
                    value: value2,
                    child: Text(value2),
                  );
                }).toList(),
                decoration: InputDecoration(
                  labelText: 'Gasolina',
                ),
                validator: (value2) {
                  if (value2 == null || value2.isEmpty) {
                    return 'Por favor, seleccione el tipo de gasolina';
                  }
                  return null;
                },
              ),

              TextFormField(
                controller: _tanqueController,
                decoration: InputDecoration(
                  labelText: 'Capacidad del tanque (en litros)',
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, ingrese la capacidad del tanque';
                  } else if (int.tryParse(value) == null) {
                    return 'Por favor, ingrese un número válido';
                  }
                  return null;
                },
              ),

              TextFormField(
                controller: _trabajadorController,
                decoration: InputDecoration(
                  labelText: 'Trabajador responsable',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, ingrese el nombre del trabajador responsable';
                  }
                  return null;
                },
              ),

              DropdownButtonFormField<String>(
                value: _departamentoValue,
                onChanged: (String? value3) {
                  setState(() {
                    _departamentoValue = value3 ?? _departamentoValue;
                  });
                },
                items: <String>['Materiales',
                                'Jardineria',
                                'Direccion',
                                'Seguridad',
                                'Otro',].map<DropdownMenuItem<String>>((String value3) {
                  return DropdownMenuItem<String>(
                    value: value3,
                    child: Text(value3),
                  );
                }).toList(),
                decoration: InputDecoration(
                  labelText: 'Departamento',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, seleccione el departamento';
                  }
                  return null;
                },
              ),
              SizedBox(height: 24),

              // Botones para actualizar y eliminar el vehículo
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      actualizarVehiculo();
                    },
                    child: Text('Actualizar'),
                  ),

                  ElevatedButton(
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: Text('Eliminar vehículo'),
                            content: Text('¿Está seguro de que desea eliminar este vehículo?'),
                            actions: [
                              TextButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                                child: Text('Cancelar'),
                              ),
                              TextButton(
                                onPressed: () {
                                  // Eliminar el vehículo de la base de datos
                                  eliminarVehiculo();
                                  Navigator.pop(context);
                                  Navigator.pop(context);
                                },
                                child: Text('Eliminar'),
                              ),
                            ],
                          );
                        },
                      );
                    },
                    child: Text('Eliminar'),
                  ),

                ],
              ),
              SizedBox(height: 30,),
              ElevatedButton(
                child: Text('Agregar registro de la bitácora'),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => AgregarRegistroBitacora(placa: widget.vehiculo.placa ?? ""),
                    ),
                  );
                },
              ),


            ],
          ),
        ),
      ),
    );
  }
  // Función para actualizar el vehículo en Firestore
  void actualizarVehiculo() async {
    if (_formKey.currentState!.validate()) {
      try {
        String docid = await getDocumentIdByPlaca(widget.vehiculo.placa);
        print("${widget.vehiculo.placa}");
        print(docid);
        await FirebaseFirestore.instance
            .collection('vehiculo')
            .doc(docid)
            .update({

          'tipo': _tipoValue,
          'numeroSerie': _numeroSerieController.text,
          'combustible': _gasolinaValue,
          'tanque': int.parse(_tanqueController.text),
          'trabajador': _trabajadorController.text,
          'departamento': _departamentoValue,
          'resguardadoPor': _resguardadoPorController.text,

        });
        Navigator.pop(context);
      } catch (e) {
        print('Error al actualizar el vehículo: $e');
      }
    }
  }

// Función para eliminar el vehículo de Firestore
  void eliminarVehiculo() async {
    try {
      await FirebaseFirestore.instance
          .collection('vehiculo')
          .doc(await getDocumentIdByPlaca(widget.vehiculo.placa))
          .delete();
      Navigator.pop(context);
    } catch (e) {
      print('Error al eliminar el vehículo: $e');
    }
  }
  Future<String> getDocumentIdByPlaca(String? placa) async {
    QuerySnapshot snapshot = await FirebaseFirestore.instance
        .collection('vehiculo')
        .where('placa', isEqualTo: placa)
        .get();

    if (snapshot.size > 0) {
      return snapshot.docs.first.id;
    } else {
      return "";
    }
  }
}
