import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class DetalleBitacoraScreen extends StatefulWidget {
  final String id;

  DetalleBitacoraScreen({required this.id});

  @override
  _DetalleBitacoraScreenState createState() => _DetalleBitacoraScreenState();
}

class _DetalleBitacoraScreenState extends State<DetalleBitacoraScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _verificoController = TextEditingController();
  DateTime _selectedDate = DateTime.now();
  bool _isLoading = false;
  bool _montado = false;

  @override
  void initState() {
    super.initState();
    _montado = true;
  }

  @override
  void dispose() {
    _montado = false;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detalle de bitácora'),
      ),
      body: _isLoading
          ? Center(
        child: CircularProgressIndicator(),
      )
          : StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance
            .collection('bitacoras')
            .doc(widget.id)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }

          final data = snapshot.data;

          _verificoController.text = data?['verifico'] ?? "";

          return Form(
            key: _formKey,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Text('Placa: ${data?['placa']}'),
                  Text('Fecha: ${data?['fecha']}'),
                  Text('Evento: ${data?['evento']}'),
                  Text('Recursos: ${data?['recursos']}'),
                  SizedBox(height: 16),
                  SizedBox(height: 16),
                  TextFormField(
                    controller: _verificoController,
                    decoration: InputDecoration(
                      labelText: 'Verificó',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Este campo es requerido';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () async {
                      final DateTime? date = await showDatePicker(
                        context: context,
                        initialDate: _selectedDate,
                        firstDate: DateTime(2021),
                        lastDate: DateTime(2025),
                      );
                      if (date != null) {
                        setState(() {
                          _selectedDate = date;
                        });
                      }
                    },
                    child: Text('Seleccionar fecha de verificación'),
                  ),
                  SizedBox(height: 16),
                  TextButton(
                    onPressed: () async {
                      setState(() {
                        if (_montado) {
                          setState(() {
                            _isLoading = false;
                          });
                        }
                      });

                      if (_formKey.currentState!.validate()) {
                        try {
                          final formattedDate =
                          DateFormat('dd/MM/yyyy')
                              .format(_selectedDate);

                          await FirebaseFirestore.instance
                              .collection('bitacoras')
                              .doc(widget.id)
                              .update({
                            'verifico': _verificoController.text,
                            'fechaverificacion': formattedDate,
                          });

                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                  'Se actualizó la información correctamente'),
                            ),
                          );
                        } catch (error) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                  'Ocurrió un error al actualizar la información'),
                            ),
                          );
                        }
                      }

                      setState(() {
                        _isLoading = false;
                      });
                    },
                    child: Text('Actualizar'),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
