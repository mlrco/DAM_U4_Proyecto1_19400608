class Vehiculo {
  String? placa;
  String? tipo;
  String? numeroSerie;
  String? combustible;
  int? tanque;
  String? trabajador;
  String? departamento;
  String? resguardadoPor;

  Vehiculo({
    this.placa,
    this.tipo,
    this.numeroSerie,
    this.combustible,
    this.tanque,
    this.trabajador,
    this.departamento,
    this.resguardadoPor,
  });




  set documentId(String documentId) {}

  Map<String, dynamic> toMap() {
    return {
      'placa': placa,
      'tipo': tipo,
      'numeroSerie': numeroSerie,
      'combustible': combustible,
      'tanque': tanque,
      'trabajador': trabajador,
      'departamento': departamento,
      'resguardadoPor': resguardadoPor,
    };
  }

  factory Vehiculo.fromMap(Map<String, dynamic>? map) {
    if (map == null) return Vehiculo();
    return Vehiculo(
      placa: map['placa'],
      tipo: map['tipo'],
      numeroSerie: map['numeroSerie'],
      combustible: map['combustible'],
      tanque: map['tanque'],
      trabajador: map['trabajador'],
      departamento: map['departamento'],
      resguardadoPor: map['resguardadoPor'],
    );
  }
}
